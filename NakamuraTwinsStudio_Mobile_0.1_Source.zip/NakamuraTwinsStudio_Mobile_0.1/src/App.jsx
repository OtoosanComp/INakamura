import React, { useEffect, useRef, useState } from 'react';
import {
  ImagePlus, FolderOpen, Download, RotateCw, Crop, Sun, Contrast,
  Undo2, Save, ArrowLeft, UserRound, ShieldCheck, Trash2, FileImage,
  Palette, CheckCircle2, Info, Plus, X
} from 'lucide-react';
import { saveProject, listProjects, deleteProject } from './storage.js';

const CHARACTERS = {
  tsuki: {
    id: 'tsuki', name: 'Tsuki I. Nakamura', role: 'Artista · música',
    height: '1.65 m', hair: 'Bob lavanda con raíces negras',
    eyes: 'Verdes, con borde azulado según la luz',
    build: 'Atlética; piernas musculosas, sin físico de culturista',
    marks: 'Tatuaje de huella de gato en el muslo izquierdo, cerca de la cadera',
    style: 'Reservada, disciplinada, grunge; maquillaje mínimo',
    reference: 'Añade aquí la referencia visual oficial aprobada de Tsuki.'
  },
  yami: {
    id: 'yami', name: 'Yami I. Nakamura', role: 'Cosplayer · creadora',
    height: '1.49 m', hair: 'Largo, rojo cobrizo',
    eyes: 'Verdes',
    build: 'Compacta, flexible y menos musculosa que Tsuki',
    marks: 'No añadir marcas físicas permanentes sin una referencia canónica aprobada',
    style: 'Enérgica, caótica, afectuosa y protectora',
    reference: 'Añade aquí la referencia visual oficial aprobada de Yami.'
  }
};

const newId = () => `nts-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

function readFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function App() {
  const [screen, setScreen] = useState('home');
  const [character, setCharacter] = useState('tsuki');
  const [projects, setProjects] = useState([]);
  const [project, setProject] = useState(null);
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const canvasRef = useRef(null);
  const fileRef = useRef(null);
  const [adjust, setAdjust] = useState({ brightness: 100, contrast: 100, saturation: 100 });
  const [rotation, setRotation] = useState(0);
  const [crop, setCrop] = useState(false);
  const [history, setHistory] = useState([]);

  useEffect(() => { refreshProjects(); }, []);
  useEffect(() => { if (project?.imageData) drawImage(); }, [project?.imageData, adjust, rotation, crop]);

  async function refreshProjects() {
    try { setProjects(await listProjects()); }
    catch { setNotice('No se pudo leer el almacenamiento local.'); }
  }

  function flash(message) {
    setNotice(message);
    window.setTimeout(() => setNotice(''), 3200);
  }

  async function drawImage() {
    const canvas = canvasRef.current;
    if (!canvas || !project?.imageData) return;
    try {
      const img = await loadImage(project.imageData);
      const angle = ((rotation % 360) + 360) % 360;
      const swapped = angle === 90 || angle === 270;
      canvas.width = (swapped ? img.height : img.width);
      canvas.height = (swapped ? img.width : img.height);
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate(angle * Math.PI / 180);
      ctx.filter = `brightness(${adjust.brightness}%) contrast(${adjust.contrast}%) saturate(${adjust.saturation}%)`;
      ctx.drawImage(img, -img.width / 2, -img.height / 2);
      ctx.restore();
    } catch { flash('No se pudo cargar esta imagen.'); }
  }

  function pushHistory() {
    setHistory(old => [...old.slice(-9), { adjust: { ...adjust }, rotation, crop }]);
  }

  async function importImage(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { flash('Elige un archivo de imagen.'); return; }
    if (file.size > 18 * 1024 * 1024) { flash('Para esta versión, usa imágenes de hasta 18 MB.'); return; }
    setBusy(true);
    try {
      const imageData = await readFile(file);
      const img = await loadImage(imageData);
      const p = {
        id: newId(), name: file.name.replace(/\.[^.]+$/, '') || 'Proyecto sin título',
        character, imageData, originalData: imageData,
        width: img.width, height: img.height,
        adjust: { brightness: 100, contrast: 100, saturation: 100 },
        rotation: 0, crop: false, createdAt: new Date().toISOString()
      };
      setProject(p);
      setAdjust(p.adjust);
      setRotation(0);
      setCrop(false);
      setHistory([]);
      setScreen('editor');
      flash('Imagen cargada. El original se conserva.');
    } catch { flash('No se pudo importar la imagen.'); }
    finally { setBusy(false); event.target.value = ''; }
  }

  async function createBlankProject() {
    const blank = document.createElement('canvas');
    blank.width = 1080; blank.height = 1350;
    const ctx = blank.getContext('2d');
    ctx.fillStyle = '#211b2b'; ctx.fillRect(0, 0, blank.width, blank.height);
    ctx.fillStyle = '#d8c3f4'; ctx.font = 'bold 44px sans-serif';
    ctx.textAlign = 'center'; ctx.fillText('Nakamura Twins Studio', 540, 620);
    ctx.fillStyle = '#b7a7c9'; ctx.font = '28px sans-serif';
    ctx.fillText('Importa una imagen para comenzar', 540, 680);
    const imageData = blank.toDataURL('image/png');
    const p = { id: newId(), name: 'Nuevo proyecto', character, imageData, originalData: imageData, width: 1080, height: 1350, adjust: { brightness: 100, contrast: 100, saturation: 100 }, rotation: 0, crop: false, createdAt: new Date().toISOString() };
    setProject(p); setAdjust(p.adjust); setRotation(0); setCrop(false); setHistory([]); setScreen('editor');
  }

  async function saveCurrent() {
    if (!project) return;
    setBusy(true);
    try {
      const canvas = canvasRef.current;
      const rendered = canvas?.toDataURL('image/png') || project.imageData;
      const record = { ...project, character, imageData: project.originalData || project.imageData, previewData: rendered, adjust: { ...adjust }, rotation, crop };
      await saveProject(record);
      setProject(record);
      await refreshProjects();
      flash('Proyecto guardado en este dispositivo.');
    } catch (err) {
      flash('No se pudo guardar. Prueba con una imagen más pequeña.');
    } finally { setBusy(false); }
  }

  async function openProject(p) {
    setProject({ ...p, imageData: p.originalData || p.imageData });
    setCharacter(p.character || 'tsuki');
    setAdjust(p.adjust || { brightness: 100, contrast: 100, saturation: 100 });
    setRotation(p.rotation || 0);
    setCrop(Boolean(p.crop));
    setHistory([]);
    setScreen('editor');
  }

  function resetAdjustments() {
    pushHistory();
    setAdjust({ brightness: 100, contrast: 100, saturation: 100 });
    setRotation(0); setCrop(false);
    if (project?.originalData) setProject({ ...project, imageData: project.originalData });
    flash('Ajustes restablecidos.');
  }

  function undo() {
    if (!history.length) { flash('No hay más cambios en el historial.'); return; }
    const previous = history[history.length - 1];
    setHistory(history.slice(0, -1));
    setAdjust(previous.adjust); setRotation(previous.rotation); setCrop(previous.crop);
  }

  async function cropCenter() {
    if (!project?.imageData) return;
    pushHistory();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const x = Math.floor(canvas.width * 0.08);
    const y = Math.floor(canvas.height * 0.08);
    const w = Math.floor(canvas.width * 0.84);
    const h = Math.floor(canvas.height * 0.84);
    const data = ctx.getImageData(x, y, w, h);
    canvas.width = w; canvas.height = h;
    canvas.getContext('2d').putImageData(data, 0, 0);
    const croppedData = canvas.toDataURL('image/png');
    setProject({ ...project, imageData: croppedData, originalData: croppedData, width: w, height: h });
    setAdjust({ brightness: 100, contrast: 100, saturation: 100 });
    setRotation(0); setCrop(true);
    flash('Recorte central aplicado. Guarda para conservarlo.');
  }

  function exportImage() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.toBlob(blob => {
      if (!blob) { flash('No se pudo exportar la imagen.'); return; }
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(project?.name || 'nts-proyecto').replace(/[^\w\-]+/g, '_')}.png`;
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
      flash('Exportación PNG solicitada.');
    }, 'image/png');
  }

  async function exportBackup() {
    if (!project) return;
    const data = JSON.stringify({ format: 'NTS', version: 1, project: { ...project, adjust, rotation, crop, character } }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${project.name.replace(/[^\w\-]+/g, '_')}.nts.json`;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    flash('Copia de proyecto exportada.');
  }

  async function removeProject(id) {
    try { await deleteProject(id); await refreshProjects(); flash('Proyecto eliminado.'); }
    catch { flash('No se pudo eliminar el proyecto.'); }
  }

  const activeCharacter = CHARACTERS[character] || CHARACTERS.tsuki;

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand-mark">NT</div>
      <div className="brand-copy"><strong>Nakamura Twins Studio</strong><span>Mobile · 0.1</span></div>
      <div className="offline-pill"><span className="dot"/> Local</div>
    </header>

    {notice && <div className="toast" role="status"><Info size={16}/>{notice}<button aria-label="Cerrar aviso" onClick={() => setNotice('')}><X size={15}/></button></div>}

    {screen === 'home' && <main className="home-screen">
      <section className="hero">
        <div className="eyebrow">TU ESTUDIO PORTÁTIL</div>
        <h1>Dos artistas.<br/><span>Un universo.</span></h1>
        <p>Un espacio compacto para editar imágenes y cuidar el canon de las gemelas Nakamura.</p>
        <button className="primary-button" onClick={createBlankProject}><Plus size={18}/> Crear proyecto</button>
        <button className="secondary-button" onClick={() => fileRef.current?.click()}><ImagePlus size={18}/> Importar imagen</button>
        <input ref={fileRef} type="file" accept="image/*" hidden onChange={importImage}/>
      </section>

      <section className="section-block">
        <div className="section-heading"><h2>Personajes</h2><span>Canon inicial</span></div>
        <div className="character-grid">
          {Object.values(CHARACTERS).map(c => <button key={c.id} className={`character-card ${character === c.id ? 'selected' : ''}`} onClick={() => setCharacter(c.id)}>
            <div className={`character-avatar ${c.id}`}><UserRound size={31}/></div>
            <strong>{c.id === 'tsuki' ? 'Tsuki' : 'Yami'}</strong>
            <span>{c.id === 'tsuki' ? 'Lavanda · Grunge' : 'Cobrizo · Cosplay'}</span>
            <small>{c.height}</small>
            {character === c.id && <CheckCircle2 className="selected-check" size={17}/>}
          </button>)}
        </div>
        <div className="canon-note"><ShieldCheck size={17}/><span>Las fichas son datos iniciales. Añade las imágenes canónicas aprobadas cuando las tengas disponibles.</span></div>
      </section>

      <section className="section-block">
        <div className="section-heading"><h2>Proyectos guardados</h2><span>{projects.length}</span></div>
        {projects.length === 0 ? <div className="empty-state"><FolderOpen size={27}/><strong>Aún no hay proyectos</strong><span>Importa una imagen o crea tu primer proyecto.</span></div> :
          <div className="project-list">{projects.map(p => <div className="project-row" key={p.id}>
            <button className="project-open" onClick={() => openProject(p)}><img src={p.previewData || p.imageData} alt="" /><span><strong>{p.name}</strong><small>{p.character === 'yami' ? 'Yami' : 'Tsuki'} · {new Date(p.updatedAt || p.createdAt || Date.now()).toLocaleDateString('es-MX')}</small></span></button>
            <button className="icon-button danger" aria-label={`Eliminar ${p.name}`} onClick={() => removeProject(p.id)}><Trash2 size={17}/></button>
          </div>)}</div>}
      </section>
      <footer>Hecho para Tsuki y Yami Nakamura · Los datos se guardan localmente.</footer>
    </main>}

    {screen === 'editor' && <main className="editor-screen">
      <div className="editor-heading">
        <button className="icon-button" onClick={() => { setScreen('home'); refreshProjects(); }} aria-label="Volver"><ArrowLeft/></button>
        <div className="editor-title"><strong>{project?.name || 'Proyecto'}</strong><small>{activeCharacter.name}</small></div>
        <button className="icon-button" onClick={saveCurrent} disabled={busy} aria-label="Guardar"><Save/></button>
      </div>
      <div className="canvas-wrap">
        {project?.imageData ? <canvas ref={canvasRef} className="work-canvas" aria-label="Lienzo de edición"/> : <div className="canvas-placeholder"><FileImage size={34}/><span>Importa una imagen para empezar</span></div>}
      </div>
      <div className="canvas-meta"><span>{project?.width || 0} × {project?.height || 0} px · PNG</span><span>Edición local</span></div>

      <section className="tool-section">
        <div className="section-heading"><h2><Palette size={17}/> Ajustes</h2><button className="text-button" onClick={resetAdjustments}>Restablecer</button></div>
        <label className="range-control"><span><Sun size={16}/> Brillo <b>{adjust.brightness}%</b></span><input type="range" min="25" max="175" value={adjust.brightness} onPointerDown={pushHistory} onChange={e => setAdjust({...adjust, brightness: Number(e.target.value)})}/></label>
        <label className="range-control"><span><Contrast size={16}/> Contraste <b>{adjust.contrast}%</b></span><input type="range" min="25" max="175" value={adjust.contrast} onPointerDown={pushHistory} onChange={e => setAdjust({...adjust, contrast: Number(e.target.value)})}/></label>
        <label className="range-control"><span><Palette size={16}/> Saturación <b>{adjust.saturation}%</b></span><input type="range" min="0" max="200" value={adjust.saturation} onPointerDown={pushHistory} onChange={e => setAdjust({...adjust, saturation: Number(e.target.value)})}/></label>
      </section>

      <section className="tool-section">
        <div className="section-heading"><h2>Herramientas rápidas</h2></div>
        <div className="tool-grid">
          <button onClick={() => { pushHistory(); setRotation((rotation + 90) % 360); }}><RotateCw/><span>Rotar 90°</span></button>
          <button onClick={cropCenter}><Crop/><span>Recorte central</span></button>
          <button onClick={undo}><Undo2/><span>Deshacer</span></button>
          <button onClick={() => fileRef.current?.click()}><ImagePlus/><span>Cambiar imagen</span></button>
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={importImage}/>
        </div>
      </section>

      <section className="tool-section">
        <div className="section-heading"><h2>Ficha canónica</h2><span>{activeCharacter.id === 'tsuki' ? 'TSUKI' : 'YAMI'}</span></div>
        <div className="canon-card">
          <div className={`canon-swatch ${activeCharacter.id}`}/>
          <div className="canon-details">
            <strong>{activeCharacter.name}</strong>
            <p><b>Cabello:</b> {activeCharacter.hair}</p>
            <p><b>Ojos:</b> {activeCharacter.eyes}</p>
            <p><b>Altura:</b> {activeCharacter.height}</p>
            <p><b>Complexión:</b> {activeCharacter.build}</p>
            <p><b>Rasgos:</b> {activeCharacter.marks}</p>
            <p><b>Personalidad:</b> {activeCharacter.style}</p>
            <div className="reference-slot"><ImagePlus size={16}/><span>{activeCharacter.reference}</span></div>
          </div>
        </div>
      </section>

      <div className="bottom-actions">
        <button className="secondary-button" onClick={exportBackup}><Download size={17}/> Exportar proyecto</button>
        <button className="primary-button" onClick={exportImage}><FileImage size={17}/> Exportar PNG</button>
      </div>
      <footer>Guarda con frecuencia. Esta versión no sustituye archivos originales.</footer>
    </main>}
  </div>;
}

export default App;
