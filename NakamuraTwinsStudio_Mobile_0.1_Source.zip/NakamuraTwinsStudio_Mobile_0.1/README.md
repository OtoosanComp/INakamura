# Nakamura Twins Studio Mobile 0.1

Prototipo inicial de aplicación Android, offline-first, especializado en las fichas y proyectos de Tsuki y Yami Nakamura.

## Incluye
- Pantalla de inicio con selección de Tsuki/Yami.
- Fichas canónicas iniciales con espacios para incorporar referencias oficiales.
- Importación de imágenes.
- Ajustes de brillo, contraste y saturación.
- Rotación de 90 grados y recorte central.
- Deshacer básico de ajustes.
- Guardado local con IndexedDB.
- Exportación PNG y exportación de copia JSON `.nts.json`.
- Flujo de GitHub Actions para generar un APK de depuración.

## Limitaciones conocidas de 0.1
- Es un prototipo funcional inicial, no un sustituto de Photoshop.
- No tiene aún capas múltiples, máscaras, pinceles de retoque ni IA.
- El recorte central es una operación destructiva sobre la imagen actual; guarda una copia antes de usarlo.
- La exportación `.nts.json` es un respaldo de proyecto en desarrollo; todavía no es un formato `.nts` estable ni garantiza portabilidad completa entre versiones.
- La aplicación aún no ha sido compilada ni verificada en un dispositivo real. El APK solo existirá después de una ejecución exitosa de GitHub Actions.
- En esta versión, la biblioteca de referencias contiene texto guía, no imágenes canónicas incorporadas.

## Compilar el APK usando solo el teléfono

1. Crea una cuenta en GitHub desde el navegador si aún no tienes una.
2. Crea un repositorio nuevo llamado `nakamura-twins-studio`. Para subir este ZIP, primero extráelo en el teléfono. GitHub web no siempre permite subir carpetas completas; si resulta incómodo, se puede usar GitHub Codespaces desde el navegador o subir los archivos por partes. Codespaces puede tener límites de cuota o solicitar un método de pago.
3. Sube todo el contenido de esta carpeta al nivel raíz del repositorio, incluyendo la carpeta oculta `.github`.
4. Abre la pestaña **Actions** del repositorio y habilita los workflows si GitHub lo solicita.
5. En **Build Nakamura Twins Studio APK**, selecciona **Run workflow**. También se ejecuta en cada `push` a `main`.
6. Espera a que la ejecución termine en verde. Abre esa ejecución y baja hasta **Artifacts**.
7. Descarga `Nakamura-Twins-Studio-Mobile-0.1-debug-apk` (ZIP), extráelo y localiza `app-debug.apk`.
8. Toca el APK en Archivos. Si Android lo solicita, permite temporalmente que esa aplicación instale apps desconocidas. Instala y abre la app. Revoca el permiso después si lo deseas.

## Stack
- React + Vite
- Capacitor 6
- IndexedDB para proyectos locales
- GitHub Actions para compilar Android en la nube

## Para desarrollo futuro
1. Probar la compilación real de Android y corregir cualquier problema del entorno.
2. Probar importación, guardado y exportación en el Moto G82.
3. Añadir referencias oficiales aprobadas.
4. Mejorar recorte no destructivo, historial y guardado de ajustes.
5. Diseñar el formato `.nts` portable y una versión de escritorio.
6. Añadir sincronización opcional solo después de validar el almacenamiento local.

## Canon inicial incluido
### Tsuki I. Nakamura
- 1.65 m.
- Cabello lavanda bob con raíces negras.
- Ojos verdes, con borde azulado según la iluminación.
- Piernas atléticas y musculosas, sin físico de culturista.
- Tatuaje de huella de gato en el muslo izquierdo, cerca de la cadera.
- Artista, música, reservada y de estilo grunge.

### Yami I. Nakamura
- 1.49 m.
- Cabello largo rojo cobrizo.
- Ojos verdes.
- Complexión compacta, flexible y menos musculosa que Tsuki.
- Cosplayer, enérgica, afectuosa y protectora.

Las fichas son datos iniciales para apoyar la coherencia visual, no un detector automático de canon.
