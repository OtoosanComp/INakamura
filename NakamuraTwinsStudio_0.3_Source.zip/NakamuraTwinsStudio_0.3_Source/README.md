# Nakamura Twins Studio 0.3 — fuente inicial

Aplicación React + TypeScript + Vite preparada para empaquetarse como APK con Capacitor 6.

## Incluido
- Captura desde cámara trasera usando la API de cámara de Capacitor.
- Importar una foto desde el dispositivo.
- Perfiles de tratamiento visual locales: **Yami / Princesa Cosplayer** y **Tsuki / Cine dramático**.
- Ajustes locales de brillo, contraste y saturación con vista previa Canvas.
- Guardado de original y resultado en el almacenamiento de la app; opción de compartir/guardar el PNG resultante.
- Proyectos listados en almacenamiento local del navegador.
- Panel de IA online como integración pendiente: no llama a un proveedor ni genera imágenes todavía.
- Canon separado por personaje para que Yami y Tsuki compartan editor sin mezclar identidades.

## Estado honesto
Este paquete es **código fuente inicial**. No se ha compilado ni probado en un Motorola desde este entorno. No contiene credenciales de IA, ni un backend de generación de imágenes. Los filtros son ajustes fotográficos locales, no IA generativa. El guardado de proyectos usa almacenamiento local del WebView; para producción conviene migrarlo a una base de datos nativa/IndexedDB robusta y verificar la persistencia en Android.

## Compilar APK con GitHub Actions desde el teléfono
1. Crea un repositorio nuevo en GitHub y sube el contenido de este ZIP a la raíz.
2. Abre el repositorio en GitHub, pestaña **Actions**, y permite ejecutar workflows si GitHub lo solicita.
3. El workflow `Android APK` instala dependencias, crea el proyecto Android con Capacitor, sincroniza la app y compila un APK debug.
4. Cuando termine, abre la ejecución y descarga el artefacto `NakamuraTwinsStudio-debug-apk`.
5. Instala el APK en tu teléfono. Android puede mostrar la advertencia habitual de instalación de una app fuera de Play Store.

Si el workflow falla, comparte una captura o el log de error para corregirlo.

## Requisitos
Node 20; Android SDK instalado por el workflow. El archivo `android/` se genera en CI.

## Cámara
La cámara trasera se solicita como preferencia. Android puede devolver una cámara disponible según dispositivo/permisos. Debes aceptar el permiso de cámara. En navegador web, la cámara normalmente requiere HTTPS y puede comportarse diferente.

## Próximos pasos
- Probar compilación real en GitHub Actions.
- Añadir configuración segura de un proveedor de IA (no incluir claves secretas en la app).
- Mejorar guardado nativo y exportación a galería con permisos correctos.
- Pruebas en el Moto G82 5G.
